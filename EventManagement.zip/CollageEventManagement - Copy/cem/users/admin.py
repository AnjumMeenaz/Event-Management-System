from django.contrib import admin
from .models import Profile, show, studentregister, prize
admin.site.register(Profile)
admin.site.register(show)
admin.site.register(studentregister)
admin.site.register(prize)


